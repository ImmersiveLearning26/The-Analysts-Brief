// SharedLove UI building blocks: plain-DOM versions of the design system components
// (same class names as design-system/project/components, styled by ui.css + tokens.css).
import { ICONS } from './icons.js';

// el('div', { class: 'x', onclick: fn, text: 'hi' }, child, child…)
export function el(tag, attrs = {}, ...children) {
  const e = document.createElement(tag);
  for (const [k, v] of Object.entries(attrs || {})) {
    if (v == null || v === false) continue;
    if (k === 'class') e.className = v;
    else if (k === 'text') e.textContent = v;
    else if (k === 'style' && typeof v === 'object') Object.assign(e.style, v);
    else if (k.startsWith('on')) e.addEventListener(k.slice(2), v);
    else e.setAttribute(k, v === true ? '' : v);
  }
  for (const c of children.flat()) if (c != null && c !== false) e.append(c);
  return e;
}

export function icon(name, size = 20) {
  const ns = 'http://www.w3.org/2000/svg';
  const svg = document.createElementNS(ns, 'svg');
  for (const [k, v] of Object.entries({ class: 'sl-icon', width: size, height: size, viewBox: '0 0 24 24', fill: 'none', stroke: 'currentColor', 'stroke-width': 1.5, 'stroke-linecap': 'round', 'stroke-linejoin': 'round', 'aria-hidden': 'true' })) svg.setAttribute(k, v);
  svg.innerHTML = ICONS[name] || ''; // our own static icon paths
  return svg;
}

export function button({ text, icon: ic, trailingIcon, variant = 'fill', size = 'md', onClick, type = 'button', className = '' }) {
  const s = size === 'lg' ? 24 : 18;
  return el('button', { type, class: `sl-btn sl-btn--${variant} sl-btn--${size} ${className}`, onclick: onClick },
    ic && icon(ic, s), text != null && el('span', { text }), trailingIcon && icon(trailingIcon, s));
}

export function iconButton({ icon: ic, label, variant = 'fill', size = 'md', shape = 'circle', onClick, className = '' }) {
  const s = size === 'lg' ? 28 : size === 'sm' ? 16 : 20;
  const b = el('button', { type: 'button', class: `sl-icobtn sl-icobtn--${variant} sl-icobtn--${size} sl-icobtn--${shape} ${className}`, 'aria-label': label, title: label, onclick: onClick }, icon(ic, s));
  b.setIcon = (name) => b.replaceChildren(icon(name, s));
  b.setLabel = (l) => { b.setAttribute('aria-label', l); b.title = l; };
  return b;
}

const STATE_WORDS = { here: 'Watching', away: 'Stepped away', loading: 'Catching up', off: 'Here' };
export function presence({ name, state = 'here', detail, you }) {
  return el('div', { class: `sl-presence sl-presence--${state}` },
    el('span', { class: 'sl-presence__avatar', 'aria-hidden': 'true' }, (name || '?').trim().charAt(0).toUpperCase(), el('span', { class: 'sl-presence__dot' })),
    el('span', null,
      el('div', { class: 'sl-presence__name', text: name + (you ? ' (you)' : '') }),
      el('div', { class: 'sl-presence__state', text: detail || STATE_WORDS[state] })));
}

export function slider({ label, value = 0, min = 0, max = 100, step = 1, unit = '%', onChange }) {
  const fill = el('div', { class: 'sl-slider__fill' });
  const tick = el('div', { class: 'sl-slider__tick' });
  const val = el('span', { class: 'sl-slider__value' });
  const root = el('div', { class: 'sl-slider', role: 'slider', tabindex: '0', 'aria-label': label, 'aria-valuemin': min, 'aria-valuemax': max },
    fill, tick, el('span', { class: 'sl-slider__label', text: label }), val);
  let v = value, dragging = false;
  function show() {
    const pct = ((v - min) / (max - min)) * 100;
    fill.style.width = pct + '%'; tick.style.left = pct + '%';
    val.textContent = v + unit; root.setAttribute('aria-valuenow', v);
  }
  function set(n, fire = true) {
    n = Math.min(max, Math.max(min, Math.round(n / step) * step));
    if (n === v && !fire) return;
    v = n; show(); if (fire && onChange) onChange(v);
  }
  const fromEvent = (e) => { const r = root.getBoundingClientRect(); set(min + ((e.clientX - r.left) / r.width) * (max - min)); };
  root.addEventListener('pointerdown', (e) => { root.setPointerCapture(e.pointerId); dragging = true; root.classList.add('is-dragging'); fromEvent(e); });
  root.addEventListener('pointermove', (e) => { if (dragging) fromEvent(e); });
  const end = () => { dragging = false; root.classList.remove('is-dragging'); };
  root.addEventListener('pointerup', end); root.addEventListener('pointercancel', end);
  root.addEventListener('keydown', (e) => {
    const d = ['ArrowRight', 'ArrowUp'].includes(e.key) ? step : ['ArrowLeft', 'ArrowDown'].includes(e.key) ? -step : 0;
    if (d) { e.preventDefault(); set(v + d * (e.shiftKey ? 10 : 1)); }
  });
  show();
  root.set = (n) => set(n, false);
  return root;
}

export function disclosure({ title, meta, icon: ic, open = false, content }) {
  const metaEl = el('span', { class: 'sl-disc__meta', text: meta || '' });
  const id = 'd' + Math.random().toString(36).slice(2, 8);
  const trigger = el('button', { type: 'button', class: 'sl-disc__trigger', 'aria-expanded': String(open), 'aria-controls': id },
    ic && icon(ic, 20), el('span', { text: title }), metaEl, el('span', { class: 'sl-disc__chev' }, icon('chevron-down', 18)));
  const contentEl = el('div', { class: 'sl-disc__content' }, content);
  const body = el('div', { class: 'sl-disc__body', id, role: 'region' }, el('div', { class: 'sl-disc__inner' }, contentEl));
  const root = el('div', { class: 'sl-disc' + (open ? ' is-open' : '') }, trigger, body);
  const setOpen = (o) => {
    open = o; root.classList.toggle('is-open', o); trigger.setAttribute('aria-expanded', String(o));
    if (o) body.removeAttribute('inert'); else body.setAttribute('inert', '');
  };
  trigger.addEventListener('click', () => setOpen(!open));
  setOpen(open);
  root.setMeta = (m) => { metaEl.textContent = m; };
  root.setContent = (...c) => contentEl.replaceChildren(...c);
  root.setOpen = setOpen;
  return root;
}

// Single-choice list; the highlight glides to the chosen row (first placement is instant).
export function list({ items, value, label, onChange }) {
  const hl = el('div', { class: 'sl-list__hl', style: { opacity: '0', transition: 'none' } });
  const root = el('div', { class: 'sl-list', role: 'listbox', 'aria-label': label || '' }, hl);
  let placed = false;
  function place(animate) {
    const row = root.querySelector('[aria-selected="true"]');
    if (!row) { hl.style.opacity = '0'; return; }
    hl.style.transition = animate ? '' : 'none';
    hl.style.transform = `translateY(${row.offsetTop}px)`;
    hl.style.height = row.offsetHeight + 'px';
    hl.style.opacity = '1';
  }
  function select(id, fire) {
    value = id;
    for (const r of root.querySelectorAll('.sl-row')) { const on = r.dataset.id === id; r.setAttribute('aria-selected', String(on)); r.tabIndex = on ? 0 : -1; }
    place(placed); placed = true;
    if (fire && onChange) onChange(id);
  }
  for (const it of items) {
    const thumb = it.thumb ? el('span', { class: 'sl-row__thumb', style: /^(#|rgb|hsl)/.test(it.thumb) ? { background: it.thumb } : { backgroundImage: `url(${it.thumb})` } })
      : it.icon ? el('span', { class: 'sl-row__icon' }, icon(it.icon, 18)) : null;
    root.append(el('button', { type: 'button', role: 'option', class: 'sl-row', 'data-id': it.id, 'aria-selected': 'false', onclick: () => select(it.id, true) },
      thumb, el('span', { class: 'sl-row__label', text: it.label }), it.meta && el('span', { class: 'sl-row__meta', text: it.meta })));
  }
  requestAnimationFrame(() => { if (value != null) select(value, false); });
  root.select = (id) => select(id, false);
  return root;
}

// Sheets grow out of whatever opened them, and shrink back into it.
let openSheetEl = null;
export function openSheet(sheet, trigger) {
  if (openSheetEl && openSheetEl !== sheet) closeSheet(openSheetEl);
  openSheetEl = sheet;
  sheet.hidden = false;
  if (trigger) {
    const t = trigger.getBoundingClientRect(), s = sheet.getBoundingClientRect();
    sheet.style.transformOrigin = `${t.left + t.width / 2 - s.left}px ${t.top + t.height / 2 - s.top}px`;
  }
  sheet._trigger = trigger;
  trigger?.setAttribute('aria-expanded', 'true');
  // Contents arrive one after another (style.css: .sheet.is-open > *).
  [...sheet.children].forEach((c, i) => c.style.setProperty('--i', i));
  document.body.classList.add('has-sheet');
  requestAnimationFrame(() => requestAnimationFrame(() => sheet.classList.add('is-open')));
  const focusable = sheet.querySelector('input, button, [tabindex="0"]');
  setTimeout(() => focusable?.focus({ preventScroll: true }), 200);
}
export function closeSheet(sheet = openSheetEl) {
  if (!sheet || sheet.hidden) return;
  sheet.classList.remove('is-open');
  if (openSheetEl === sheet) openSheetEl = null;
  sheet._trigger?.setAttribute('aria-expanded', 'false');
  document.body.classList.remove('has-sheet');
  const done = () => { if (!sheet.classList.contains('is-open')) sheet.hidden = true; };
  sheet.addEventListener('transitionend', done, { once: true });
  setTimeout(done, 400);
  sheet._trigger?.focus?.({ preventScroll: true });
}
export const sheetIsOpen = () => !!openSheetEl;
document.addEventListener('keydown', (e) => { if (e.key === 'Escape') closeSheet(); });
document.addEventListener('pointerdown', (e) => {
  if (!openSheetEl) return;
  if (openSheetEl.contains(e.target) || openSheetEl._trigger?.contains(e.target)) return;
  closeSheet();
}, true);
