// SharedLove motion: real springs, so the interface reacts like it has weight.
//
// The principles of animation, applied to every control:
//   anticipation      press → the control squashes a little before anything happens
//   follow-through    release → it springs past its resting size, then settles
//   overlapping action the icon inside lags behind its button, and wiggles to rest
//   squash & stretch  pills squash wider as they're pressed; volume is preserved
//   slow in/out       springs accelerate and settle on their own, never linearly
//   appeal            hover leans gently toward the pointer; a soft light blooms where you tap
//
// Springs are simulated (not keyframed), so any motion can be interrupted mid-flight and
// will carry its momentum into the next one. Uses the individual `scale`, `translate`
// and `rotate` properties, so it never fights a component's own `transform`.

const REDUCED = matchMedia('(prefers-reduced-motion: reduce)');

// ---- Springs --------------------------------------------------------------------------
// stiffness k, damping c (mass 1). ζ = c / 2√k: lower = bouncier.
export const SPRINGS = {
  hover:   { k: 320, c: 22 },   // ζ≈0.61: gentle lean, barely overshoots
  press:   { k: 900, c: 42 },   // ζ≈0.70: quick, firm squash (anticipation)
  release: { k: 380, c: 15 },   // ζ≈0.38: lively overshoot, then settles (follow-through)
  icon:    { k: 240, c: 11 },   // ζ≈0.35: looser than its button, so it lags and wiggles
  magnet:  { k: 260, c: 20 },
};

function spring(x, cfg) { return { x, v: 0, to: x, k: cfg.k, c: cfg.c }; }
function retarget(s, to, cfg, kick = 0) { s.to = to; if (cfg) { s.k = cfg.k; s.c = cfg.c; } s.v += kick; }
function step(s, dt) {
  const a = -s.k * (s.x - s.to) - s.c * s.v;
  s.v += a * dt; s.x += s.v * dt;
  if (Math.abs(s.v) < 0.002 && Math.abs(s.x - s.to) < 0.0005) { s.x = s.to; s.v = 0; return false; }
  return true;
}

// ---- Per-element state ------------------------------------------------------------------
const states = new Map();      // element → its springs
let running = false, last = 0;

function stateFor(el) {
  let s = states.get(el);
  if (!s) {
    const kind = kindOf(el);
    s = {
      el, kind,
      scale: spring(1, SPRINGS.hover), squash: spring(0, SPRINGS.press),
      tx: spring(0, SPRINGS.magnet), ty: spring(0, SPRINGS.magnet),
      iScale: spring(1, SPRINGS.icon), iRot: spring(0, SPRINGS.icon),
      hovered: false, pressed: false,
    };
    states.set(el, s);
  }
  return s;
}

// How strongly each kind of thing reacts: small things move more, big things barely.
const PROFILES = {
  icon:  { hover: 1.06, press: 0.88, squash: 0,    lean: 2.5, kick: 2.6, iconPress: 0.8, wiggle: 260 },
  pill:  { hover: 1.03, press: 0.95, squash: 0.04, lean: 2,   kick: 1.6, iconPress: 0.86, wiggle: 160 },
  row:   { hover: 1.0,  press: 0.97, squash: 0,    lean: 0,   kick: 0.9, iconPress: 0.9, wiggle: 0 },
  card:  { hover: 1.012, press: 0.985, squash: 0,  lean: 3,   kick: 0.5, iconPress: 1, wiggle: 0 },
};
function kindOf(el) {
  if (el.matches('.sl-media, .sl-media--interactive')) return 'card';
  if (el.matches('.sl-row, .sl-disc__trigger')) return 'row';
  if (el.matches('.sl-icobtn, .sl-faces, .faces')) return 'icon';
  return 'pill';
}

function render(s) {
  const el = s.el, sc = s.scale.x, q = s.squash.x;
  // Squash & stretch keeps volume: wider and shorter together.
  el.style.scale = q ? `${(sc * (1 + q)).toFixed(4)} ${(sc * (1 - q)).toFixed(4)}` : sc.toFixed(4);
  el.style.translate = s.tx.x || s.ty.x ? `${s.tx.x.toFixed(2)}px ${s.ty.x.toFixed(2)}px` : '';
  const icon = el.querySelector(':scope > svg, :scope > .sl-icobtn > svg, :scope > .sl-icon');
  if (icon) {
    icon.style.scale = s.iScale.x.toFixed(4);
    icon.style.rotate = s.iRot.x ? s.iRot.x.toFixed(2) + 'deg' : '';
  }
}

function loop(t) {
  const dt = Math.min(0.032, (t - last) / 1000 || 0.016);
  last = t;
  let any = false;
  for (const s of states.values()) {
    if (!s.el.isConnected) { states.delete(s.el); continue; }
    // Two half-steps for stability on stiff springs.
    let moving = false;
    for (const sp of [s.scale, s.squash, s.tx, s.ty, s.iScale, s.iRot]) {
      const a = step(sp, dt / 2), b = step(sp, dt / 2);
      moving = moving || a || b;
    }
    render(s);
    any = any || moving;
  }
  if (any) requestAnimationFrame(loop); else running = false;
}
function wake() { if (!running) { running = true; last = performance.now(); requestAnimationFrame(loop); } }

// ---- Reactions ------------------------------------------------------------------------------
function hover(el, on) {
  const s = stateFor(el), p = PROFILES[s.kind];
  s.hovered = on;
  if (s.pressed) return;
  retarget(s.scale, on ? p.hover : 1, SPRINGS.hover);
  if (!on) { retarget(s.tx, 0); retarget(s.ty, 0); }
  wake();
}
function lean(el, e) {
  const s = stateFor(el), p = PROFILES[s.kind];
  if (!p.lean || s.pressed) return;
  const r = el.getBoundingClientRect();
  const dx = (e.clientX - (r.left + r.width / 2)) / (r.width / 2), dy = (e.clientY - (r.top + r.height / 2)) / (r.height / 2);
  retarget(s.tx, Math.max(-1, Math.min(1, dx)) * p.lean);
  retarget(s.ty, Math.max(-1, Math.min(1, dy)) * p.lean * 0.7);
  wake();
}
function press(el) {
  const s = stateFor(el), p = PROFILES[s.kind];
  s.pressed = true;
  retarget(s.scale, p.press, SPRINGS.press);            // anticipation
  retarget(s.squash, p.squash, SPRINGS.press);          // squash wide
  retarget(s.iScale, p.iconPress, SPRINGS.press);
  wake();
}
function release(el, fire) {
  const s = stateFor(el), p = PROFILES[s.kind];
  if (!s.pressed) return;
  s.pressed = false;
  const kick = fire ? p.kick : 0;
  retarget(s.scale, s.hovered ? p.hover : 1, SPRINGS.release, kick);   // follow-through: overshoot, settle
  retarget(s.squash, 0, SPRINGS.release, fire ? -p.squash * 18 : 0);   // stretch tall for a beat
  retarget(s.iScale, 1, SPRINGS.icon, fire ? kick * 1.4 : 0);          // the icon lags, then overshoots more
  if (fire && p.wiggle) retarget(s.iRot, 0, SPRINGS.icon, (Math.random() < 0.5 ? -1 : 1) * p.wiggle);
  wake();
}

// A soft light that blooms from where you tapped, inside the control's own shape.
function bloom(el, x, y) {
  if (REDUCED.matches) return;
  let layer = el.querySelector(':scope > .sl-bloom-layer');
  if (!layer) { layer = document.createElement('span'); layer.className = 'sl-bloom-layer'; el.append(layer); }
  const r = el.getBoundingClientRect();
  const dot = document.createElement('span');
  dot.className = 'sl-bloom';
  const size = Math.max(r.width, r.height) * 2.2;
  Object.assign(dot.style, { width: size + 'px', height: size + 'px', left: (x - r.left - size / 2) + 'px', top: (y - r.top - size / 2) + 'px' });
  layer.append(dot);
  dot.addEventListener('animationend', () => dot.remove(), { once: true });
}

// ---- Wiring: one set of listeners for the whole page ------------------------------------------
const SELECTOR = '.sl-btn, .sl-icobtn, .dock__start, .sl-row, .sl-media--interactive, .faces, .sl-faces, .glass-pill, .sl-disc__trigger';
const target = (e) => (e.target instanceof Element ? e.target.closest(SELECTOR) : null);

export function enableMotion(root = document) {
  let hovered = null, pressed = null;
  root.addEventListener('pointerover', (e) => {
    if (REDUCED.matches || e.pointerType === 'touch') return;
    const el = target(e);
    if (el === hovered) return;
    if (hovered) hover(hovered, false);
    hovered = el;
    if (el) { el.classList.add('is-springy'); hover(el, true); }
  });
  root.addEventListener('pointerout', (e) => {
    if (!hovered || (e.relatedTarget instanceof Node && hovered.contains(e.relatedTarget))) return;
    hover(hovered, false); hovered = null;
  });
  root.addEventListener('pointermove', (e) => { if (hovered && !REDUCED.matches) lean(hovered, e); }, { passive: true });
  root.addEventListener('pointerdown', (e) => {
    const t = target(e); if (!t || REDUCED.matches || t.disabled) return;
    pressed = t; t.classList.add('is-springy'); press(t);
  });
  const up = (e, fire) => {
    if (!pressed) return;
    const el = pressed; pressed = null;
    const inside = fire && e.target instanceof Node && el.contains(e.target);
    release(el, inside);
    if (inside) bloom(el, e.clientX, e.clientY);
    if (e.pointerType === 'touch') { hover(el, false); }
  };
  root.addEventListener('pointerup', (e) => up(e, true));
  root.addEventListener('pointercancel', (e) => up(e, false));
  // Keyboard presses get the same life (Enter / Space on a focused control).
  root.addEventListener('keydown', (e) => {
    if ((e.key === 'Enter' || e.key === ' ') && !e.repeat && document.activeElement?.matches?.(SELECTOR)) press(document.activeElement);
  });
  root.addEventListener('keyup', (e) => {
    const el = document.activeElement;
    if ((e.key === 'Enter' || e.key === ' ') && el?.matches?.(SELECTOR)) { release(el, true); const r = el.getBoundingClientRect(); bloom(el, r.left + r.width / 2, r.top + r.height / 2); }
  });
}

// For other code: give any element a little "I changed" pop (e.g. a status dot).
export function pop(el, amount = 2) {
  if (!el || REDUCED.matches) return;
  const s = stateFor(el);
  retarget(s.scale, 1, SPRINGS.release, amount);
  wake();
}

// For tests and tuning.
export const _debug = { states, SPRINGS, PROFILES };
