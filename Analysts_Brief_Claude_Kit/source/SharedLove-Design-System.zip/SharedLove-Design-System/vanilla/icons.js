// SharedLove icons: 24-grid line icons, 1.5 stroke (design system set + a few app additions).
export const ICONS = {
 "play": "<path d=\"M8 5.5v13a1 1 0 0 0 1.5.86l10.5-6.5a1 1 0 0 0 0-1.72L9.5 4.64A1 1 0 0 0 8 5.5z\"/>",
 "pause": "<rect x=\"6.5\" y=\"5\" width=\"3.5\" height=\"14\" rx=\"1\"/><rect x=\"14\" y=\"5\" width=\"3.5\" height=\"14\" rx=\"1\"/>",
 "plus": "<path d=\"M12 5v14M5 12h14\"/>",
 "search": "<circle cx=\"11\" cy=\"11\" r=\"6.5\"/><path d=\"M20 20l-4.2-4.2\"/>",
 "arrow-up-right": "<path d=\"M7 17L17 7M9 7h8v8\"/>",
 "globe": "<circle cx=\"12\" cy=\"12\" r=\"8.5\"/><path d=\"M3.5 12h17M12 3.5c2.5 2.6 3.5 5.3 3.5 8.5s-1 5.9-3.5 8.5c-2.5-2.6-3.5-5.3-3.5-8.5s1-5.9 3.5-8.5z\"/>",
 "heart": "<path d=\"M12 19.5s-7-4.3-7-9.6A3.9 3.9 0 0 1 12 7.6a3.9 3.9 0 0 1 7 2.3c0 5.3-7 9.6-7 9.6z\"/>",
 "volume": "<path d=\"M5 9.5h3l4-3.5v12l-4-3.5H5z\"/><path d=\"M15.5 9a4 4 0 0 1 0 6M18 6.5a7.5 7.5 0 0 1 0 11\"/>",
 "screen": "<rect x=\"3.5\" y=\"5\" width=\"17\" height=\"11.5\" rx=\"2\"/><path d=\"M9 20h6M12 16.5V20\"/>",
 "close": "<path d=\"M6.5 6.5l11 11M17.5 6.5l-11 11\"/>",
 "chevron-down": "<path d=\"M6.5 9.5L12 15l5.5-5.5\"/>",
 "person": "<circle cx=\"12\" cy=\"8.5\" r=\"3.5\"/><path d=\"M5 19.5c1.2-3.3 3.8-5 7-5s5.8 1.7 7 5\"/>",
 "expand": "<path d=\"M14 5h5v5M10 19H5v-5M19 5l-6 6M5 19l6-6\"/>",
 "back": "<path d=\"M14.5 6L8.5 12l6 6\"/>",
 "subtitles": "<rect x=\"3.5\" y=\"5.5\" width=\"17\" height=\"13\" rx=\"2.5\"/><path d=\"M7.5 14.5h4M13.5 14.5h3M7.5 11h2M11.5 11h5\"/>",
 "film": "<rect x=\"4\" y=\"4.5\" width=\"16\" height=\"15\" rx=\"2.5\"/><path d=\"M8 4.5v15M16 4.5v15M4 9.5h4M4 14.5h4M16 9.5h4M16 14.5h4\"/>",
 "link": "<path d=\"M10 14a4 4 0 0 0 5.66 0l3-3a4 4 0 0 0-5.66-5.66l-1 1\"/><path d=\"M14 10a4 4 0 0 0-5.66 0l-3 3a4 4 0 0 0 5.66 5.66l1-1\"/>"
};
