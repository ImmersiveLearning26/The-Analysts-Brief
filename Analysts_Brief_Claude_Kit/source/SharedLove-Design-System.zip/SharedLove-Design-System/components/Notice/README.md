# Notice

One quiet line over the picture, saying only what someone can act on or needs to know right now.

**Provide** `children` (the words; empty or `shown={false}` hides it). Position it yourself — the app centres it near the top of the video.

- Glass pill, `on-media` text, `label`-size type. Fades and drops in with `ease-spring`; fades out with `ease-in`, keeping its last words while it goes.
- Use for: “Ada stepped away”, “Waiting for Ada to tap play”, “Connecting to Moses’s screen…”, a one-off error.
- One at a time. It disappears on its own when the situation clears — never ask people to dismiss it.
