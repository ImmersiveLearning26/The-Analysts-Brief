import type * as React from 'react';

export type IconName =
  | 'play' | 'pause' | 'plus' | 'search' | 'arrow-up-right' | 'globe'
  | 'heart' | 'volume' | 'screen' | 'close' | 'chevron-down' | 'person'
  | 'expand' | 'back' | 'subtitles' | 'film' | 'link';

export interface IconProps { name: IconName; size?: number; strokeWidth?: number; label?: string; className?: string }
export declare function Icon(props: IconProps): React.ReactElement;

export interface ButtonProps extends React.ButtonHTMLAttributes<HTMLButtonElement> {
  variant?: 'fill' | 'soft' | 'solid' | 'accent' | 'ghost' | 'glass';
  size?: 'md' | 'lg';
  icon?: IconName;
  trailingIcon?: IconName;
}
export declare function Button(props: ButtonProps): React.ReactElement;

export interface IconButtonProps extends React.ButtonHTMLAttributes<HTMLButtonElement> {
  icon: IconName;
  /** Required: the accessible name and tooltip. */
  label: string;
  variant?: 'fill' | 'soft' | 'solid' | 'accent' | 'ghost' | 'glass';
  size?: 'sm' | 'md' | 'lg';
  shape?: 'circle' | 'pill' | 'squircle';
}
export declare function IconButton(props: IconButtonProps): React.ReactElement;

export interface MediaCardProps {
  image?: string;
  alt?: string;
  title?: React.ReactNode;
  subtitle?: React.ReactNode;
  /** CSS aspect-ratio, default "16 / 9". */
  aspect?: string;
  hero?: boolean;
  /** One node, usually a glass IconButton, pinned bottom-right. */
  action?: React.ReactNode;
  onClick?: (e: React.SyntheticEvent) => void;
  className?: string;
  style?: React.CSSProperties;
}
export declare function MediaCard(props: MediaCardProps): React.ReactElement;

export interface DockProps { leading?: React.ReactNode; trailing?: React.ReactNode; children?: React.ReactNode; className?: string; role?: string }
export declare function Dock(props: DockProps): React.ReactElement & { Text: (props: { children?: React.ReactNode }) => React.ReactElement };

export interface PanelProps { title?: string; children?: React.ReactNode; className?: string; style?: React.CSSProperties }
export declare function Panel(props: PanelProps): React.ReactElement;

export interface ListItem { id: string; label: React.ReactNode; /** Image URL or a colour. */ thumb?: string; meta?: React.ReactNode }
export interface ListProps { items: ListItem[]; label?: string; value?: string; defaultValue?: string; onChange?: (id: string) => void }
export declare function List(props: ListProps): React.ReactElement;

export interface SliderProps {
  label: string;
  value?: number; defaultValue?: number; onChange?: (value: number) => void;
  min?: number; max?: number; step?: number;
  /** Appended to the value, default "%". */
  unit?: string;
  format?: (value: number) => React.ReactNode;
}
export declare function Slider(props: SliderProps): React.ReactElement;

export interface DisclosureProps {
  title: React.ReactNode;
  children?: React.ReactNode;
  meta?: React.ReactNode;
  icon?: IconName;
  open?: boolean; defaultOpen?: boolean; onOpenChange?: (open: boolean) => void;
  className?: string;
}
export declare function Disclosure(props: DisclosureProps): React.ReactElement;

export interface PresenceProps { name: string; state?: 'here' | 'away' | 'loading' | 'off'; detail?: React.ReactNode; you?: boolean; className?: string }
export declare function Presence(props: PresenceProps): React.ReactElement;

export interface PlayerBarProps {
  playing: boolean;
  /** Seconds. */ position: number;
  /** Seconds. */ duration: number;
  onToggle?: () => void;
  onSeek?: (seconds: number) => void;
  trailing?: React.ReactNode;
  autoHide?: boolean; idleMs?: number; hidden?: boolean;
  wakeTarget?: EventTarget;
  className?: string;
}
export declare function PlayerBar(props: PlayerBarProps): React.ReactElement;

export interface SheetProps {
  open: boolean;
  onClose?: () => void;
  /** Ref to the element that opened it: the sheet grows from there. */
  anchorRef?: React.RefObject<HTMLElement>;
  title?: string;
  children?: React.ReactNode;
  className?: string;
  /** Position it here (it is position: absolute). */
  style?: React.CSSProperties;
}
export declare function Sheet(props: SheetProps): React.ReactElement | null & {
  Section: (props: { label?: string; children?: React.ReactNode }) => React.ReactElement;
  Hint: (props: { children?: React.ReactNode }) => React.ReactElement;
  Actions: (props: { children?: React.ReactNode }) => React.ReactElement;
};

export interface NoticeProps { children?: React.ReactNode; shown?: boolean; className?: string; style?: React.CSSProperties }
export declare function Notice(props: NoticeProps): React.ReactElement;

export interface FacesProps { people: { id?: string | number; name: string; state?: 'here' | 'away' | 'loading' | 'off' }[]; onClick?: () => void; label?: string; className?: string }
export declare function Faces(props: FacesProps): React.ReactElement;

export interface FieldProps {
  size?: 'md' | 'lg';
  value?: string; defaultValue?: string; onChange?: (value: string) => void;
  onSubmit?: (value: string) => void;
  placeholder?: string; label?: string;
  actionIcon?: IconName; actionLabel?: string;
  type?: string; inputMode?: React.HTMLAttributes<HTMLInputElement>['inputMode'];
  autoComplete?: string; maxLength?: number; required?: boolean; autoFocus?: boolean;
  className?: string;
}
export declare function Field(props: FieldProps): React.ReactElement;

declare global {
  interface Window {
    SharedLove: {
      Button: typeof Button; IconButton: typeof IconButton; MediaCard: typeof MediaCard; Dock: typeof Dock;
      Panel: typeof Panel; List: typeof List; Slider: typeof Slider; Disclosure: typeof Disclosure;
      Presence: typeof Presence; PlayerBar: typeof PlayerBar; Sheet: typeof Sheet; Notice: typeof Notice;
      Faces: typeof Faces; Field: typeof Field; Icon: typeof Icon; ICON_NAMES: IconName[];
    };
  }
}
