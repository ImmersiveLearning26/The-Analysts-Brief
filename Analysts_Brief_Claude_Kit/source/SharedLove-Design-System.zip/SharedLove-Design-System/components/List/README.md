# List

Single-choice rows with an optional thumbnail; the highlight glides to the chosen row.

**Provide** `items` (`[{ id, label, thumb?, meta? }]` — `thumb` is an image URL or a colour), `label` (accessible name), and either `value` + `onChange` (controlled) or `defaultValue`.

- Unselected rows are `ink-muted`; the selected row turns `ink` on `fill-soft`.
- The highlight moves with `duration-3` / `ease-out`; the first placement is instant.
- Arrow keys move the choice. Use inside a Panel; up to ~7 rows.
