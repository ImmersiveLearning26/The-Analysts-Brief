# Sheet

A floating panel that grows out of whatever opened it and shrinks back into it — for choices that don't deserve a screen (Start something, the Room, Join on Netflix).

**Provide** `open`, `onClose`, `anchorRef` (a ref to the trigger, so it grows from there), optionally `title`, and `style` / `className` to place it (it is `position: absolute`; the app pins Start above the Dock and the Room under the faces). Compose its body from `Sheet.Section` (optional `label`), `Sheet.Hint` and `Sheet.Actions`.

- Opens: scale 0.94 → 1, 6px rise, 2px blur clearing, `duration-3` / `ease-out`, from the trigger. Closes faster, `duration-2` / `ease-in`, back into it.
- Closes on Escape, on a tap outside, or with its ✕. Never stack two sheets — opening one closes the other.
- One topic per sheet; one `accent` action at most inside it. If it needs to scroll, it's too big — move rare things into a Disclosure.
