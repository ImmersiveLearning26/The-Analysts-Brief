# MediaCard

Imagery in the signature `radius-xl` squircle, with an optional light title and one action.

**Provide** `image` (URL), `alt` (empty when decorative), and optionally `title`, `subtitle`, `aspect` (CSS aspect-ratio, default `16 / 9`), `hero` (larger title), `action` (one node, usually a `glass` IconButton) and `onClick` (makes the whole card a button).

- Title in `display` style, light weight, centred, `on-media`; the card adds `media-scrim` automatically whenever there is text.
- One action at most, bottom-right. Never stack buttons on media.
- Hover slowly scales the image to 1.035 over `duration-4` — the card itself never moves.
- Use for: what's playing now, the invitation to join, a movie in a short list. Not for settings.
