/* @ds-bundle: {"format":4,"namespace":"SharedLove","components":[{"name":"Button"},{"name":"IconButton"},{"name":"MediaCard"},{"name":"Dock"},{"name":"Panel"},{"name":"List"},{"name":"Slider"},{"name":"Disclosure"},{"name":"Presence"},{"name":"PlayerBar"},{"name":"Sheet"},{"name":"Notice"},{"name":"Faces"},{"name":"Field"},{"name":"Icon"}]} */
(function () {
  var React = window.React, h = React.createElement;
  var useState = React.useState, useRef = React.useRef, useEffect = React.useEffect, useLayoutEffect = React.useLayoutEffect;

  function cx() { return Array.prototype.filter.call(arguments, Boolean).join(' '); }
  function omit(obj, keys) { var o = {}; for (var k in obj) if (keys.indexOf(k) < 0) o[k] = obj[k]; return o; }
  function useControlled(value, initial) {
    var s = useState(initial), inner = s[0], setInner = s[1];
    return [value !== undefined ? value : inner, setInner];
  }

  var ICONS = {"play": "<path d=\"M8 5.5v13a1 1 0 0 0 1.5.86l10.5-6.5a1 1 0 0 0 0-1.72L9.5 4.64A1 1 0 0 0 8 5.5z\"/>", "pause": "<rect x=\"6.5\" y=\"5\" width=\"3.5\" height=\"14\" rx=\"1\"/><rect x=\"14\" y=\"5\" width=\"3.5\" height=\"14\" rx=\"1\"/>", "plus": "<path d=\"M12 5v14M5 12h14\"/>", "search": "<circle cx=\"11\" cy=\"11\" r=\"6.5\"/><path d=\"M20 20l-4.2-4.2\"/>", "arrow-up-right": "<path d=\"M7 17L17 7M9 7h8v8\"/>", "globe": "<circle cx=\"12\" cy=\"12\" r=\"8.5\"/><path d=\"M3.5 12h17M12 3.5c2.5 2.6 3.5 5.3 3.5 8.5s-1 5.9-3.5 8.5c-2.5-2.6-3.5-5.3-3.5-8.5s1-5.9 3.5-8.5z\"/>", "heart": "<path d=\"M12 19.5s-7-4.3-7-9.6A3.9 3.9 0 0 1 12 7.6a3.9 3.9 0 0 1 7 2.3c0 5.3-7 9.6-7 9.6z\"/>", "volume": "<path d=\"M5 9.5h3l4-3.5v12l-4-3.5H5z\"/><path d=\"M15.5 9a4 4 0 0 1 0 6M18 6.5a7.5 7.5 0 0 1 0 11\"/>", "screen": "<rect x=\"3.5\" y=\"5\" width=\"17\" height=\"11.5\" rx=\"2\"/><path d=\"M9 20h6M12 16.5V20\"/>", "close": "<path d=\"M6.5 6.5l11 11M17.5 6.5l-11 11\"/>", "chevron-down": "<path d=\"M6.5 9.5L12 15l5.5-5.5\"/>", "person": "<circle cx=\"12\" cy=\"8.5\" r=\"3.5\"/><path d=\"M5 19.5c1.2-3.3 3.8-5 7-5s5.8 1.7 7 5\"/>", "expand": "<path d=\"M14 5h5v5M10 19H5v-5M19 5l-6 6M5 19l6-6\"/>", "back": "<path d=\"M14.5 6L8.5 12l6 6\"/>", "subtitles": "<rect x=\"3.5\" y=\"5.5\" width=\"17\" height=\"13\" rx=\"2.5\"/><path d=\"M7.5 14.5h4M13.5 14.5h3M7.5 11h2M11.5 11h5\"/>", "film": "<rect x=\"4\" y=\"4.5\" width=\"16\" height=\"15\" rx=\"2.5\"/><path d=\"M8 4.5v15M16 4.5v15M4 9.5h4M4 14.5h4M16 9.5h4M16 14.5h4\"/>", "link": "<path d=\"M10 14a4 4 0 0 0 5.66 0l3-3a4 4 0 0 0-5.66-5.66l-1 1\"/><path d=\"M14 10a4 4 0 0 0-5.66 0l-3 3a4 4 0 0 0 5.66 5.66l1-1\"/>"};

  /* Icon: 24-grid line icons, 1.5 stroke, round caps. Colour = currentColor. */
  function Icon(p) {
    var size = p.size || 20;
    return h('svg', {
      className: cx('sl-icon', p.className), width: size, height: size, viewBox: '0 0 24 24', fill: 'none',
      stroke: 'currentColor', strokeWidth: p.strokeWidth || 1.5, strokeLinecap: 'round', strokeLinejoin: 'round',
      'aria-hidden': p.label ? undefined : true, role: p.label ? 'img' : undefined, 'aria-label': p.label,
      dangerouslySetInnerHTML: { __html: ICONS[p.name] || '' }
    });
  }

  /* Button: the pill. */
  function Button(p) {
    var variant = p.variant || 'fill', size = p.size || 'md';
    var rest = omit(p, ['variant', 'size', 'icon', 'trailingIcon', 'className', 'children']);
    var is = size === 'lg' ? 24 : 18;
    return h('button', Object.assign({ type: 'button' }, rest, { className: cx('sl-btn', 'sl-btn--' + variant, 'sl-btn--' + size, p.className) }),
      p.icon ? h(Icon, { name: p.icon, size: is }) : null,
      p.children != null ? h('span', null, p.children) : null,
      p.trailingIcon ? h(Icon, { name: p.trailingIcon, size: is }) : null);
  }

  /* IconButton: one icon, always with an accessible label. */
  function IconButton(p) {
    var variant = p.variant || 'fill', size = p.size || 'md', shape = p.shape || 'circle';
    var rest = omit(p, ['variant', 'size', 'shape', 'icon', 'label', 'className']);
    var is = size === 'lg' ? 28 : size === 'sm' ? 16 : 20;
    return h('button', Object.assign({ type: 'button', 'aria-label': p.label, title: p.label }, rest, {
      className: cx('sl-icobtn', 'sl-icobtn--' + variant, 'sl-icobtn--' + size, 'sl-icobtn--' + shape, p.className)
    }), h(Icon, { name: p.icon, size: is }));
  }

  /* MediaCard: imagery in the signature squircle, optional title and one action. */
  function MediaCard(p) {
    var interactive = !!p.onClick;
    return h('div', {
      className: cx('sl-media', interactive && 'sl-media--interactive', p.hero && 'sl-media--hero', p.className),
      style: Object.assign({ aspectRatio: p.aspect || '16 / 9' }, p.style),
      onClick: p.onClick, role: interactive ? 'button' : undefined, tabIndex: interactive ? 0 : undefined,
      onKeyDown: interactive ? function (e) { if (e.key === 'Enter' || e.key === ' ') { e.preventDefault(); p.onClick(e); } } : undefined
    },
      p.image ? h('img', { className: 'sl-media__img', src: p.image, alt: p.alt || '' }) : null,
      (p.title || p.subtitle) ? h('div', { className: 'sl-media__scrim' }) : null,
      (p.title || p.subtitle) ? h('div', { className: 'sl-media__text' },
        p.title ? h('div', { className: 'sl-media__title' }, p.title) : null,
        p.subtitle ? h('div', { className: 'sl-media__sub' }, p.subtitle) : null) : null,
      p.action ? h('div', { className: 'sl-media__action', onClick: function (e) { e.stopPropagation(); } }, p.action) : null);
  }

  /* Dock: a bar with a leading tile, a centre, and trailing actions. */
  function Dock(p) {
    return h('div', { className: cx('sl-dock', p.className), role: p.role },
      p.leading ? h('div', { className: 'sl-dock__lead' }, p.leading) : null,
      h('div', { className: 'sl-dock__body' }, p.children),
      p.trailing ? h('div', { className: 'sl-dock__trail' }, p.trailing) : null);
  }
  Dock.Text = function (p) { return h('span', { className: 'sl-dock__text' }, p.children); };

  /* Panel: small floating card for settings and menus. */
  function Panel(p) {
    return h('section', { className: cx('sl-panel', p.className), style: p.style, 'aria-label': p.title },
      p.title ? h('div', { className: 'sl-panel__title' }, p.title) : null, p.children);
  }

  /* List: single-select rows; the highlight glides to the selected row. */
  function List(p) {
    var items = p.items || [];
    var sel = useControlled(p.value, p.defaultValue !== undefined ? p.defaultValue : (items[0] && items[0].id));
    var value = sel[0], setValue = sel[1];
    var listRef = useRef(null), hl = useState({ y: 0, h: 0, ready: false, glide: false }), box = hl[0], setBox = hl[1];
    useLayoutEffect(function () {
      var el = listRef.current && listRef.current.querySelector('[aria-selected="true"]');
      if (!el) return;
      // First placement is instant; only later selection changes glide.
      setBox(function (b) { return { y: el.offsetTop, h: el.offsetHeight, ready: true, glide: b.ready }; });
    }, [value, items.length]);
    function choose(id) { setValue(id); if (p.onChange) p.onChange(id); }
    function onKey(e) {
      var i = items.findIndex(function (x) { return x.id === value; });
      if (e.key === 'ArrowDown' || e.key === 'ArrowUp') {
        e.preventDefault();
        var n = items[(i + (e.key === 'ArrowDown' ? 1 : items.length - 1)) % items.length];
        choose(n.id);
        var btn = listRef.current.querySelector('[data-id="' + n.id + '"]'); if (btn) btn.focus();
      }
    }
    return h('div', { className: 'sl-list', role: 'listbox', 'aria-label': p.label, ref: listRef, onKeyDown: onKey },
      h('div', { className: 'sl-list__hl', style: { transform: 'translateY(' + box.y + 'px)', height: box.h + 'px', opacity: box.ready ? 1 : 0, transition: box.glide ? undefined : 'none' } }),
      items.map(function (it) {
        var on = it.id === value;
        var thumb = it.thumb ? h('span', { className: 'sl-row__thumb', style: /^(#|rgb|hsl)/.test(it.thumb) ? { background: it.thumb } : { backgroundImage: 'url(' + it.thumb + ')' } }) : null;
        return h('button', { key: it.id, type: 'button', role: 'option', 'aria-selected': on, 'data-id': it.id, tabIndex: on ? 0 : -1, className: 'sl-row', onClick: function () { choose(it.id); } },
          thumb, h('span', null, it.label), it.meta ? h('span', { className: 'sl-row__meta' }, it.meta) : null);
      }));
  }

  /* Slider: a quiet filled bar with its label inside and its value at the end. */
  function Slider(p) {
    var min = p.min != null ? p.min : 0, max = p.max != null ? p.max : 100, step = p.step || 1;
    var st = useControlled(p.value, p.defaultValue != null ? p.defaultValue : min), value = st[0], setValue = st[1];
    var drag = useState(false), dragging = drag[0], setDragging = drag[1];
    var ref = useRef(null);
    function set(v) { v = Math.min(max, Math.max(min, Math.round(v / step) * step)); setValue(v); if (p.onChange) p.onChange(v); }
    function fromEvent(e) { var r = ref.current.getBoundingClientRect(); set(min + ((e.clientX - r.left) / r.width) * (max - min)); }
    var pct = ((value - min) / (max - min)) * 100;
    var unit = p.unit != null ? p.unit : '%';
    return h('div', {
      ref: ref, className: cx('sl-slider', dragging && 'is-dragging'), role: 'slider', tabIndex: 0,
      'aria-label': p.label, 'aria-valuemin': min, 'aria-valuemax': max, 'aria-valuenow': value, 'aria-valuetext': value + unit,
      onPointerDown: function (e) { ref.current.setPointerCapture(e.pointerId); setDragging(true); fromEvent(e); },
      onPointerMove: function (e) { if (dragging) fromEvent(e); },
      onPointerUp: function () { setDragging(false); },
      onPointerCancel: function () { setDragging(false); },
      onKeyDown: function (e) {
        var d = e.key === 'ArrowRight' || e.key === 'ArrowUp' ? step : e.key === 'ArrowLeft' || e.key === 'ArrowDown' ? -step : 0;
        if (d) { e.preventDefault(); set(value + d * (e.shiftKey ? 10 : 1)); }
      }
    },
      h('div', { className: 'sl-slider__fill', style: { width: pct + '%' } }),
      h('div', { className: 'sl-slider__tick', style: { left: pct + '%' } }),
      h('span', { className: 'sl-slider__label' }, p.label),
      h('span', { className: 'sl-slider__value' }, (p.format ? p.format(value) : value + unit)));
  }

  /* Disclosure: closed by default; opens with a fluid height + fade, closes faster. */
  function Disclosure(p) {
    var st = useControlled(p.open, !!p.defaultOpen), open = st[0], setOpen = st[1];
    var id = useRef('sl-d' + Math.random().toString(36).slice(2, 8)).current;
    function toggle() { var n = !open; setOpen(n); if (p.onOpenChange) p.onOpenChange(n); }
    return h('div', { className: cx('sl-disc', open && 'is-open', p.className) },
      h('button', { type: 'button', className: 'sl-disc__trigger', 'aria-expanded': open, 'aria-controls': id, onClick: toggle },
        p.icon ? h(Icon, { name: p.icon, size: 20 }) : null,
        h('span', null, p.title),
        p.meta ? h('span', { className: 'sl-disc__meta' }, p.meta) : h('span', { style: { marginLeft: 'auto' } }),
        h('span', { className: 'sl-disc__chev' }, h(Icon, { name: 'chevron-down', size: 18 }))),
      h('div', { className: 'sl-disc__body', id: id, role: 'region', 'aria-hidden': !open, inert: open ? undefined : '' },
        h('div', { className: 'sl-disc__inner' }, h('div', { className: 'sl-disc__content' }, p.children))));
  }

  /* Presence: who is watching, and in what state — dot and words together. */
  var STATE_WORDS = { here: 'Watching', away: 'Stepped away', loading: 'Catching up', off: 'Not here' };
  function Presence(p) {
    var state = p.state || 'here';
    return h('div', { className: cx('sl-presence', 'sl-presence--' + state, p.className) },
      h('span', { className: 'sl-presence__avatar', 'aria-hidden': true }, (p.name || '?').trim().charAt(0).toUpperCase(), h('span', { className: 'sl-presence__dot' })),
      h('span', null,
        h('div', { className: 'sl-presence__name' }, p.name + (p.you ? ' (you)' : '')),
        h('div', { className: 'sl-presence__state' }, p.detail || STATE_WORDS[state])));
  }

  /* PlayerBar: glass transport over video. Hides itself after idle while playing. */
  function fmt(s) {
    s = Math.max(0, Math.floor(s || 0));
    var hh = Math.floor(s / 3600), m = Math.floor((s % 3600) / 60), ss = s % 60;
    return (hh ? hh + ':' + String(m).padStart(2, '0') : m) + ':' + String(ss).padStart(2, '0');
  }
  function PlayerBar(p) {
    var trackRef = useRef(null);
    var idle = useState(false), hidden = idle[0], setHidden = idle[1];
    var timer = useRef(null);
    function wake() {
      setHidden(false); clearTimeout(timer.current);
      if (p.playing && p.autoHide !== false) timer.current = setTimeout(function () { setHidden(true); }, p.idleMs || 2500);
    }
    useEffect(function () {
      wake();
      var root = p.wakeTarget || document;
      root.addEventListener('pointermove', wake); root.addEventListener('keydown', wake); root.addEventListener('pointerdown', wake);
      return function () { clearTimeout(timer.current); root.removeEventListener('pointermove', wake); root.removeEventListener('keydown', wake); root.removeEventListener('pointerdown', wake); };
    }, [p.playing]);
    function seekFrom(e) {
      if (!p.onSeek || !p.duration) return;
      var r = trackRef.current.getBoundingClientRect();
      p.onSeek(Math.min(1, Math.max(0, (e.clientX - r.left) / r.width)) * p.duration);
    }
    var pct = p.duration ? Math.min(100, (p.position / p.duration) * 100) : 0;
    return h('div', { className: cx('sl-player', (p.hidden || hidden) && 'is-hidden', p.className), role: 'group', 'aria-label': 'Playback' },
      h(IconButton, { variant: 'glass', icon: p.playing ? 'pause' : 'play', label: p.playing ? 'Pause' : 'Play', onClick: p.onToggle }),
      h('span', { className: 'sl-player__time' }, fmt(p.position)),
      h('div', { className: 'sl-player__track', ref: trackRef, role: 'slider', 'aria-label': 'Position', 'aria-valuemin': 0, 'aria-valuemax': Math.round(p.duration || 0), 'aria-valuenow': Math.round(p.position || 0), 'aria-valuetext': fmt(p.position), tabIndex: 0,
        onPointerDown: seekFrom,
        onKeyDown: function (e) { if (!p.onSeek) return; if (e.key === 'ArrowRight') p.onSeek((p.position || 0) + 10); if (e.key === 'ArrowLeft') p.onSeek(Math.max(0, (p.position || 0) - 10)); } },
        h('div', { className: 'sl-player__rail' }),
        h('div', { className: 'sl-player__progress', style: { width: pct + '%' } })),
      h('span', { className: 'sl-player__time' }, fmt(p.duration)),
      p.trailing || null);
  }

  /* Sheet: a floating panel that grows out of whatever opened it and shrinks back into it.
     Closes on Escape or a tap outside. Position it yourself (style / className). */
  function Sheet(p) {
    var m = useState(!!p.open), mounted = m[0], setMounted = m[1];
    var sh = useState(false), shown = sh[0], setShown = sh[1];
    var ref = useRef(null);
    useEffect(function () {
      if (p.open) {
        setMounted(true);
        var r1 = requestAnimationFrame(function () { r1 = requestAnimationFrame(function () { setShown(true); }); });
        return function () { cancelAnimationFrame(r1); };
      }
      setShown(false);
      var t = setTimeout(function () { setMounted(false); }, 260);
      return function () { clearTimeout(t); };
    }, [p.open]);
    useLayoutEffect(function () {
      var a = p.anchorRef && p.anchorRef.current;
      if (!mounted || !ref.current || !a) return;
      var t = a.getBoundingClientRect(), r = ref.current.getBoundingClientRect();
      ref.current.style.transformOrigin = (t.left + t.width / 2 - r.left) + 'px ' + (t.top + t.height / 2 - r.top) + 'px';
    }, [mounted]);
    useEffect(function () {
      if (!p.open) return;
      function down(e) {
        var a = p.anchorRef && p.anchorRef.current;
        if (ref.current && !ref.current.contains(e.target) && !(a && a.contains(e.target)) && p.onClose) p.onClose();
      }
      function key(e) { if (e.key === 'Escape' && p.onClose) p.onClose(); }
      document.addEventListener('pointerdown', down, true); document.addEventListener('keydown', key);
      return function () { document.removeEventListener('pointerdown', down, true); document.removeEventListener('keydown', key); };
    }, [p.open]);
    if (!mounted) return null;
    return h('div', { ref: ref, role: 'dialog', 'aria-label': p.title, className: cx('sl-sheet', shown && 'is-open', p.className), style: p.style },
      p.title ? h('div', { className: 'sl-sheet__head' }, h('span', { className: 'sl-sheet__title' }, p.title),
        p.onClose ? h(IconButton, { icon: 'close', label: 'Close', variant: 'ghost', size: 'sm', onClick: p.onClose }) : null) : null,
      p.children);
  }
  Sheet.Section = function (p) {
    return h('div', { className: 'sl-sheet__section' }, p.label ? h('div', { className: 'sl-sheet__label' }, p.label) : null, p.children);
  };
  Sheet.Hint = function (p) { return h('p', { className: 'sl-sheet__hint' }, p.children); };
  Sheet.Actions = function (p) { return h('div', { className: 'sl-sheet__actions' }, p.children); };

  /* Notice: one quiet line over the picture. Keeps its last words while it fades out. */
  function Notice(p) {
    var last = useRef('');
    var on = !!p.children && p.shown !== false;
    if (p.children) last.current = p.children;
    return h('div', { role: 'status', 'aria-live': 'polite', className: cx('sl-notice', on && 'is-shown', p.className), style: p.style }, on ? p.children : last.current);
  }

  /* Faces: who's in the room, stacked on glass, each with a state dot. Tap for the room. */
  function Faces(p) {
    var people = p.people || [];
    return h('button', { type: 'button', className: cx('sl-faces', p.className), onClick: p.onClick, 'aria-label': p.label || ('Who’s watching: ' + people.map(function (x) { return x.name; }).join(', ')) },
      people.map(function (x, i) {
        return h('span', { key: x.id || i, className: 'sl-face', title: x.name }, (x.name || '?').trim().charAt(0).toUpperCase(),
          h('span', { className: 'sl-face__dot sl-face__dot--' + (x.state || 'here') }));
      }));
  }

  /* Field: a pill text input with one action at its end (the accent arrow). */
  function Field(p) {
    var size = p.size || 'md';
    var st = useControlled(p.value, p.defaultValue || ''), value = st[0], setValue = st[1];
    return h('form', { className: cx('sl-field', 'sl-field--' + size, p.className), onSubmit: function (e) { e.preventDefault(); if (p.onSubmit) p.onSubmit(value); } },
      h('input', { className: 'sl-field__input', value: value, placeholder: p.placeholder, 'aria-label': p.label || p.placeholder, type: p.type || 'text',
        inputMode: p.inputMode, autoComplete: p.autoComplete || 'off', maxLength: p.maxLength, required: p.required, autoFocus: p.autoFocus,
        onChange: function (e) { setValue(e.target.value); if (p.onChange) p.onChange(e.target.value); } }),
      h(IconButton, { type: 'submit', icon: p.actionIcon || 'arrow-up-right', label: p.actionLabel || 'Go', variant: 'accent', size: size === 'lg' ? 'md' : 'sm' }));
  }

  /* ---- Motion: springs for every control (also in the SharedLove app as public/motion.js) ---- */
  // SharedLove motion: real springs, so the interface reacts like it has weight.
  //
  // The principles of animation, applied to every control:
  //   anticipation      press → the control squashes a little before anything happens
  //   follow-through    release → it springs past its resting size, then settles
  //   overlapping action the icon inside lags behind its button, and wiggles to rest
  //   squash & stretch  pills squash wider as they're pressed; volume is preserved
  //   slow in/out       springs accelerate and settle on their own, never linearly
  //   appeal            hover leans gently toward the pointer; a soft light blooms where you tap
  //
  // Springs are simulated (not keyframed), so any motion can be interrupted mid-flight and
  // will carry its momentum into the next one. Uses the individual `scale`, `translate`
  // and `rotate` properties, so it never fights a component's own `transform`.

  var REDUCED = window.matchMedia('(prefers-reduced-motion: reduce)');

  // ---- Springs --------------------------------------------------------------------------
  // stiffness k, damping c (mass 1). ζ = c / 2√k: lower = bouncier.
  const SPRINGS = {
    hover:   { k: 320, c: 22 },   // ζ≈0.61: gentle lean, barely overshoots
    press:   { k: 900, c: 42 },   // ζ≈0.70: quick, firm squash (anticipation)
    release: { k: 380, c: 15 },   // ζ≈0.38: lively overshoot, then settles (follow-through)
    icon:    { k: 240, c: 11 },   // ζ≈0.35: looser than its button, so it lags and wiggles
    magnet:  { k: 260, c: 20 },
  };

  function spring(x, cfg) { return { x, v: 0, to: x, k: cfg.k, c: cfg.c }; }
  function retarget(s, to, cfg, kick = 0) { s.to = to; if (cfg) { s.k = cfg.k; s.c = cfg.c; } s.v += kick; }
  function step(s, dt) {
    const a = -s.k * (s.x - s.to) - s.c * s.v;
    s.v += a * dt; s.x += s.v * dt;
    if (Math.abs(s.v) < 0.002 && Math.abs(s.x - s.to) < 0.0005) { s.x = s.to; s.v = 0; return false; }
    return true;
  }

  // ---- Per-element state ------------------------------------------------------------------
  const states = new Map();      // element → its springs
  let running = false, last = 0;

  function stateFor(el) {
    let s = states.get(el);
    if (!s) {
      const kind = kindOf(el);
      s = {
        el, kind,
        scale: spring(1, SPRINGS.hover), squash: spring(0, SPRINGS.press),
        tx: spring(0, SPRINGS.magnet), ty: spring(0, SPRINGS.magnet),
        iScale: spring(1, SPRINGS.icon), iRot: spring(0, SPRINGS.icon),
        hovered: false, pressed: false,
      };
      states.set(el, s);
    }
    return s;
  }

  // How strongly each kind of thing reacts: small things move more, big things barely.
  const PROFILES = {
    icon:  { hover: 1.06, press: 0.88, squash: 0,    lean: 2.5, kick: 2.6, iconPress: 0.8, wiggle: 260 },
    pill:  { hover: 1.03, press: 0.95, squash: 0.04, lean: 2,   kick: 1.6, iconPress: 0.86, wiggle: 160 },
    row:   { hover: 1.0,  press: 0.97, squash: 0,    lean: 0,   kick: 0.9, iconPress: 0.9, wiggle: 0 },
    card:  { hover: 1.012, press: 0.985, squash: 0,  lean: 3,   kick: 0.5, iconPress: 1, wiggle: 0 },
  };
  function kindOf(el) {
    if (el.matches('.sl-media, .sl-media--interactive')) return 'card';
    if (el.matches('.sl-row, .sl-disc__trigger')) return 'row';
    if (el.matches('.sl-icobtn, .sl-faces, .faces')) return 'icon';
    return 'pill';
  }

  function render(s) {
    const el = s.el, sc = s.scale.x, q = s.squash.x;
    // Squash & stretch keeps volume: wider and shorter together.
    el.style.scale = q ? `${(sc * (1 + q)).toFixed(4)} ${(sc * (1 - q)).toFixed(4)}` : sc.toFixed(4);
    el.style.translate = s.tx.x || s.ty.x ? `${s.tx.x.toFixed(2)}px ${s.ty.x.toFixed(2)}px` : '';
    const icon = el.querySelector(':scope > svg, :scope > .sl-icobtn > svg, :scope > .sl-icon');
    if (icon) {
      icon.style.scale = s.iScale.x.toFixed(4);
      icon.style.rotate = s.iRot.x ? s.iRot.x.toFixed(2) + 'deg' : '';
    }
  }

  function loop(t) {
    const dt = Math.min(0.032, (t - last) / 1000 || 0.016);
    last = t;
    let any = false;
    for (const s of states.values()) {
      if (!s.el.isConnected) { states.delete(s.el); continue; }
      // Two half-steps for stability on stiff springs.
      let moving = false;
      for (const sp of [s.scale, s.squash, s.tx, s.ty, s.iScale, s.iRot]) {
        const a = step(sp, dt / 2), b = step(sp, dt / 2);
        moving = moving || a || b;
      }
      render(s);
      any = any || moving;
    }
    if (any) requestAnimationFrame(loop); else running = false;
  }
  function wake() { if (!running) { running = true; last = performance.now(); requestAnimationFrame(loop); } }

  // ---- Reactions ------------------------------------------------------------------------------
  function hover(el, on) {
    const s = stateFor(el), p = PROFILES[s.kind];
    s.hovered = on;
    if (s.pressed) return;
    retarget(s.scale, on ? p.hover : 1, SPRINGS.hover);
    if (!on) { retarget(s.tx, 0); retarget(s.ty, 0); }
    wake();
  }
  function lean(el, e) {
    const s = stateFor(el), p = PROFILES[s.kind];
    if (!p.lean || s.pressed) return;
    const r = el.getBoundingClientRect();
    const dx = (e.clientX - (r.left + r.width / 2)) / (r.width / 2), dy = (e.clientY - (r.top + r.height / 2)) / (r.height / 2);
    retarget(s.tx, Math.max(-1, Math.min(1, dx)) * p.lean);
    retarget(s.ty, Math.max(-1, Math.min(1, dy)) * p.lean * 0.7);
    wake();
  }
  function press(el) {
    const s = stateFor(el), p = PROFILES[s.kind];
    s.pressed = true;
    retarget(s.scale, p.press, SPRINGS.press);            // anticipation
    retarget(s.squash, p.squash, SPRINGS.press);          // squash wide
    retarget(s.iScale, p.iconPress, SPRINGS.press);
    wake();
  }
  function release(el, fire) {
    const s = stateFor(el), p = PROFILES[s.kind];
    if (!s.pressed) return;
    s.pressed = false;
    const kick = fire ? p.kick : 0;
    retarget(s.scale, s.hovered ? p.hover : 1, SPRINGS.release, kick);   // follow-through: overshoot, settle
    retarget(s.squash, 0, SPRINGS.release, fire ? -p.squash * 18 : 0);   // stretch tall for a beat
    retarget(s.iScale, 1, SPRINGS.icon, fire ? kick * 1.4 : 0);          // the icon lags, then overshoots more
    if (fire && p.wiggle) retarget(s.iRot, 0, SPRINGS.icon, (Math.random() < 0.5 ? -1 : 1) * p.wiggle);
    wake();
  }

  // A soft light that blooms from where you tapped, inside the control's own shape.
  function bloom(el, x, y) {
    if (REDUCED.matches) return;
    let layer = el.querySelector(':scope > .sl-bloom-layer');
    if (!layer) { layer = document.createElement('span'); layer.className = 'sl-bloom-layer'; el.append(layer); }
    const r = el.getBoundingClientRect();
    const dot = document.createElement('span');
    dot.className = 'sl-bloom';
    const size = Math.max(r.width, r.height) * 2.2;
    Object.assign(dot.style, { width: size + 'px', height: size + 'px', left: (x - r.left - size / 2) + 'px', top: (y - r.top - size / 2) + 'px' });
    layer.append(dot);
    dot.addEventListener('animationend', () => dot.remove(), { once: true });
  }

  // ---- Wiring: one set of listeners for the whole page ------------------------------------------
  const SELECTOR = '.sl-btn, .sl-icobtn, .dock__start, .sl-row, .sl-media--interactive, .faces, .sl-faces, .glass-pill, .sl-disc__trigger';
  const target = (e) => (e.target instanceof Element ? e.target.closest(SELECTOR) : null);

  function enableMotion(root = document) {
    let hovered = null, pressed = null;
    root.addEventListener('pointerover', (e) => {
      if (REDUCED.matches || e.pointerType === 'touch') return;
      const el = target(e);
      if (el === hovered) return;
      if (hovered) hover(hovered, false);
      hovered = el;
      if (el) { el.classList.add('is-springy'); hover(el, true); }
    });
    root.addEventListener('pointerout', (e) => {
      if (!hovered || (e.relatedTarget instanceof Node && hovered.contains(e.relatedTarget))) return;
      hover(hovered, false); hovered = null;
    });
    root.addEventListener('pointermove', (e) => { if (hovered && !REDUCED.matches) lean(hovered, e); }, { passive: true });
    root.addEventListener('pointerdown', (e) => {
      const t = target(e); if (!t || REDUCED.matches || t.disabled) return;
      pressed = t; t.classList.add('is-springy'); press(t);
    });
    const up = (e, fire) => {
      if (!pressed) return;
      const el = pressed; pressed = null;
      const inside = fire && e.target instanceof Node && el.contains(e.target);
      release(el, inside);
      if (inside) bloom(el, e.clientX, e.clientY);
      if (e.pointerType === 'touch') { hover(el, false); }
    };
    root.addEventListener('pointerup', (e) => up(e, true));
    root.addEventListener('pointercancel', (e) => up(e, false));
    // Keyboard presses get the same life (Enter / Space on a focused control).
    root.addEventListener('keydown', (e) => {
      if ((e.key === 'Enter' || e.key === ' ') && !e.repeat && document.activeElement?.matches?.(SELECTOR)) press(document.activeElement);
    });
    root.addEventListener('keyup', (e) => {
      const el = document.activeElement;
      if ((e.key === 'Enter' || e.key === ' ') && el?.matches?.(SELECTOR)) { release(el, true); const r = el.getBoundingClientRect(); bloom(el, r.left + r.width / 2, r.top + r.height / 2); }
    });
  }

  // For other code: give any element a little "I changed" pop (e.g. a status dot).
  function pop(el, amount = 2) {
    if (!el || REDUCED.matches) return;
    const s = stateFor(el);
    retarget(s.scale, 1, SPRINGS.release, amount);
    wake();
  }

  // For tests and tuning.
  const _debug = { states, SPRINGS, PROFILES };

  var api = { Button: Button, IconButton: IconButton, MediaCard: MediaCard, Dock: Dock, Panel: Panel, List: List, Slider: Slider, Disclosure: Disclosure, Presence: Presence, PlayerBar: PlayerBar, Sheet: Sheet, Notice: Notice, Faces: Faces, Field: Field, Icon: Icon, enableMotion: enableMotion, pop: pop, SPRINGS: SPRINGS, ICON_NAMES: Object.keys(ICONS) };
  window.SharedLove = Object.assign(window.SharedLove || {}, api);
})();
