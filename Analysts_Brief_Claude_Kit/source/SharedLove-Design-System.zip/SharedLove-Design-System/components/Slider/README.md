# Slider

A quiet filled bar with its label inside and its value at the end, for continuous settings.

**Provide** `label`, `value` + `onChange` (or `defaultValue`), and optionally `min` / `max` / `step` (default 0–100, 1), `unit` (default `%`) or `format(value)`.

- Drag anywhere on the bar, or use arrow keys (Shift for ×10). A thin tick appears at the edge while hovering or dragging.
- Values are `micro` + `ink-muted`, tabular figures so they don't jump.
- Use for volume, subtitle size, sync delay. Not for anything with fewer than five meaningful steps — use a List.
