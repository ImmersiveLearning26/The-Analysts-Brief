# Panel

A small floating card for settings and choices — `surface-raised`, `radius-md`, hairline plus `shadow-card`.

**Provide** `children` (a List, Sliders, or a few lines), and optionally `title` (shown in `caption` style) and `style` for width.

- Panels open from the thing that summons them and close when you tap outside; they are never the first thing on a screen.
- Keep one topic per panel (“Sound & sync”, “Mood”). If it needs a scroll, it's too big.
