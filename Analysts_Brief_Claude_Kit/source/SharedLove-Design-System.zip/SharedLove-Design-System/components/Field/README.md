# Field

A pill text input with one action at its end — the accent arrow that submits it.

**Provide** `placeholder`, `onSubmit(value)`, and either `value` + `onChange` or `defaultValue`; optionally `size` (`lg` 64px on `surface-raised` with a shadow — for a screen's one question, like “Your name”; `md` 48px on `fill-soft` — inside sheets), `actionIcon`, `actionLabel`, `label`, `type`, `inputMode`, `maxLength`, `required`, `autoFocus`.

- One field per form; its arrow is the screen's single `accent` action.
- Placeholder says what goes in (“Paste a YouTube link”), never instructions.
- Focus shows the 2px `focus` ring around the whole pill.
