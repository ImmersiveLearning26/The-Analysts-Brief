# Disclosure

A row that opens to reveal more — closed by default, opening with a fluid height-and-fade, closing faster.

**Provide** `title`, `children` (what's revealed), and optionally `meta` (current state, e.g. “Off”), `icon`, `defaultOpen`, or `open` + `onOpenChange`.

- Opening: height grows over `duration-3` / `ease-out`; content fades in and rises 6px, 60ms behind the height. Closing: `duration-2` / `ease-in`. The chevron turns with `ease-spring`.
- Put rarely-needed settings here so the screen stays empty until someone asks.
- `meta` shows the current value so people don't have to open it to know.
