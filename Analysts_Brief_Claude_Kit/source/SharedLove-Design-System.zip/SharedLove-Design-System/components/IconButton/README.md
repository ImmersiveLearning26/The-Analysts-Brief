# IconButton

A single icon in a circle, pill or squircle — for actions everyone recognises without words.

**Provide** `icon` (one of `SharedLove.ICON_NAMES`), `label` (required: it becomes the accessible name and tooltip), `onClick`, and optionally `variant`, `size` (`sm` 32 · `md` 44 · `lg` 64) and `shape` (`circle` · `pill` · `squircle`).

- `glass` is only for controls sitting on imagery or video (the search button on a MediaCard, the player).
- `solid` + `squircle` + `lg` is the app tile (the ♥ home button in the Dock) — one per screen.
- `accent` + `sm` is the small orange “+”: the one way to start something.
- `ghost` for tertiary icons inside bars (globe, settings).
- Don't use an icon button when the meaning isn't obvious — use a Button with words.
