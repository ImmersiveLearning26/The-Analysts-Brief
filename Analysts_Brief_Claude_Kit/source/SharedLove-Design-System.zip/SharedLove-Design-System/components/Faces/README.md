# Faces

Who's in the room, stacked on glass in the corner of the picture, each with a state dot. Tapping it opens the Room.

**Provide** `people` (`[{ id?, name, state }]`, state `here` · `away` · `loading` · `off`), `onClick`, optionally `label`.

- Initials only — the words live in the Room's Presence list, so the picture stays clean.
- Dots: `live` (here), `away` (stepped away), `ink-faint` (catching up). Fades with the rest of the player chrome when idle.
