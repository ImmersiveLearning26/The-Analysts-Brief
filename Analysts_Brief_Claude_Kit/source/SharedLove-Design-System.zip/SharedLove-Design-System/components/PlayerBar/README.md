# PlayerBar

The glass transport over video: play/pause, time, a scrub line in `accent`, duration and up to two extra icons.

**Provide** `playing`, `position` and `duration` (seconds), `onToggle`, `onSeek(seconds)`, and optionally `trailing` (glass IconButtons, `sm`), `autoHide` (default on), `idleMs` (default 2500), `hidden`, `wakeTarget`.

- While playing it fades away after 2.5s of stillness (`duration-4`) and returns on any touch, pointer move or key.
- Sits `space-4` from the edges of the video, inside its `radius-xl` frame.
- Times use the `time` style (tabular mono).
- Never show the PlayerBar and the Dock at the same time.
