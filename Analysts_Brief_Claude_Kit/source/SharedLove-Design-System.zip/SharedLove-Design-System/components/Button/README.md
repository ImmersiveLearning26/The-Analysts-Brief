# Button

The pill: every text action in SharedLove is one, and a screen shows as few as it can.

**Provide** `children` (a short verb-first label in sentence case), optionally `icon` / `trailingIcon` (an icon name), `variant`, `size`, and any button attributes (`onClick`, `disabled`).

| variant | use |
| --- | --- |
| `fill` (default) | Ordinary actions on `ground`. |
| `soft` | Actions on `ground` that should feel lighter, or on `fill` areas. |
| `solid` | The one confident secondary action (Share a tab, Turn on). |
| `accent` | The **single** primary action on a screen: “Watch together”. At most one per view. |
| `ghost` | Dismissive actions: Cancel, Not now inside a sheet. |
| `glass` | The one big action over the picture, when the browser needs a tap: “Tap for sound”, “Tap to play”. |

`size="lg"` (64px, `headline` type) is for the one large statement pill on a home screen; everything else is `md` (44px, `label`).

- Do: “Watch together”, “Join Ada”, “Pick a movie”.
- Don't: “Click here”, “OK”, Title Case, exclamation marks, two accent buttons side by side.
- Motion: presses scale to 0.97 and release with `ease-spring`; colour changes take `duration-1`.
