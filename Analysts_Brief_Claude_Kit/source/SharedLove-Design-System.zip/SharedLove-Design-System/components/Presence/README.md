# Presence

Who is in the room and how they're doing — an initial, a status dot and words, always together.

**Provide** `name`, `state` (`here` · `away` · `loading` · `off`) and optionally `detail` (replaces the default words, e.g. “In sync · 12 ms”) and `you`.

- Default words: here → “Watching”, away → “Stepped away”, loading → “Catching up”.
- Dot colours: `live` (blue) and `away` (orange) — never colour alone; the words carry the meaning.
- Show presence only when it changes something (someone left, someone's catching up); otherwise keep it one tap away.
