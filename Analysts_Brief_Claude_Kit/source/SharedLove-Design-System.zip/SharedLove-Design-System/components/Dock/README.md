# Dock

The bar at the bottom of a screen: one app tile on the left, one invitation in the middle, one quiet action on the right.

**Provide** `leading` (usually the solid squircle IconButton), `children` (centre content — typically the small accent “+” and a `Dock.Text` of two short lines), and `trailing` (a ghost IconButton).

- One Dock per screen, pinned with `space-6` from the bottom edge on phones.
- The centre says what will happen, in under eight words (“Start something to watch together”).
- When something is playing, the Dock gives way to the PlayerBar — they never show together.
