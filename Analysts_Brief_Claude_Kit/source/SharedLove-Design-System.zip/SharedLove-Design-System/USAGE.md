# Using the SharedLove Design System

Open **`index.html`** to see every component live, in Daylight and Cinema. It needs an internet connection the first time, for the Geist font (Google Fonts) and React (jsDelivr). Read **`README.md`** (the brand book) before designing a screen: it has the rules on what shows when, plus the colour, type, motion and voice guidelines.

## What's inside

```
README.md               the brand book: principles, flows, colour, type, motion, voice
USAGE.md                this file
index.html              gallery of every component (open in a browser)
tokens.json             THE source of every value: colours (two themes), type, space, radius,
                        shadow, duration, easing (incl. the two spring curves)
tokens.css              the same tokens as CSS custom properties + type classes (.title, .body…)
components/
  bundle.js             React components on window.SharedLove (needs React 18 on the page)
  bundle.css            their styles (class prefix sl-), glow, bloom, springs
  index.d.ts            TypeScript types: every component's props
  <Component>/README.md guidelines: what to provide, when to use it, do/don't
  <Component>/preview.html  a live example (open it directly)
vanilla/                the same building blocks without React, as ES modules
  ui.js                 el(), button(), iconButton(), slider(), disclosure(), list(), sheets…
  motion.js             the spring engine: enableMotion(), pop(), SPRINGS
  icons.js              the icon paths
assets/
  Icons/*.svg           17 line icons (24 grid, 1.5 stroke), drawn in `ink`
  Ambient/*.jpg         6 soft mood images for when there's no poster
  Logos/                the app icon
design-system.json      index used by the online design-system page (not needed in code)
```

## In a plain web page (with React)

```html
<link rel="stylesheet" href="tokens.css">
<link rel="stylesheet" href="components/bundle.css">
<script src="https://cdn.jsdelivr.net/npm/react@18.3.1/umd/react.production.min.js"></script>
<script src="https://cdn.jsdelivr.net/npm/react-dom@18.3.1/umd/react-dom.production.min.js"></script>
<script src="components/bundle.js"></script>

<div id="app"></div>
<script>
  var S = window.SharedLove, h = React.createElement;
  S.enableMotion();                       // springs on every control
  ReactDOM.createRoot(document.getElementById('app')).render(
    h(S.Button, { variant: 'accent', icon: 'plus' }, 'Watch together'));
</script>
```

## Without React

```html
<link rel="stylesheet" href="tokens.css">
<link rel="stylesheet" href="components/bundle.css">
<script type="module">
  import { button, slider } from './vanilla/ui.js';
  import { enableMotion } from './vanilla/motion.js';
  enableMotion();
  document.body.append(
    button({ text: 'Watch together', icon: 'plus', variant: 'accent' }),
    slider({ label: 'Volume', value: 80 }));
</script>
```

The class names are the contract: `sl-btn sl-btn--accent sl-btn--md`, `sl-sheet`, `sl-notice`, `sl-field`… work on any element, from any framework.

## Themes

Put `data-theme="light"` (Daylight) or `data-theme="dark"` (Cinema) on `<html>` or any container. Use Cinema for anything shown while something plays.

## Changing a value

Edit `tokens.json` (it's the source), then update the matching line in `tokens.css`, which follows the same names (`--accent`, `--space-4`, `--ease-bounce`…). Every component reads the CSS variables, so one change reaches everything.

## Motion in one line

Call `enableMotion()` once. Controls then squash when pressed, spring past their size when released and settle, and their icons lag and wiggle. Use `ease-spring-soft` / `duration-5` for things arriving and `ease-bounce` / `duration-6` for small reactions. Add `sl-glow` (plus `is-breathing` or `is-glowing`) to the one element that matters now. Everything calms down under `prefers-reduced-motion`.
