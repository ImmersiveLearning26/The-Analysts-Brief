SharedLove lets two people in different rooms watch the same thing at the same moment. The interface should feel like dimming the lights: calm, soft, nearly invisible, with the picture as the star. Everything here exists to get two people watching together in as few taps as possible, and then to get out of the way.

## Principles

1. **The picture is the colour.** The UI is neutral greys; colour comes from the movie, the poster, the ambient image. Don't add colour to make something feel premium; take something away instead.
2. **Show only what this moment needs.** Every screen has one job and one primary action. Everything else is one tap away (a Disclosure, a Panel), or appears only when it becomes true (someone stepped away, a screen is catching up).
3. **One accent, one meaning.** `accent` orange marks *the* thing to do, or *the* thing happening now (the progress line). If two things are orange, one is wrong.
4. **Soft shapes, quiet type.** Pills for actions, squircles for pictures, light-weight words. Nothing shouts.
5. **Everything moves like it has weight.** Things grow from where you touched them and settle softly. Nothing pops in or blinks out.

## What shows, and when

| Moment | Shows | Stays hidden |
| --- | --- | --- |
| Nothing playing | One large statement (`title`), one MediaCard or empty ground, the Dock | Settings, presence, any lists |
| The other person is watching something | One MediaCard: what they're watching, their name, one glass **Join** action (opens a Sheet with the steps for this device) | Everything else |
| Playing | The picture, edge to edge on phones and in a `radius-xl` frame on large screens | The PlayerBar, title and Faces after 2.5s of stillness, the Dock, all text |
| Someone steps away / a screen catches up | One Notice over the picture (“Ada stepped away”) and that person's dot in Faces changes | The reason, technical detail |
| Touch or move the pointer while playing | The PlayerBar, the title (top left) and Faces (top right) fade in | Settings stay in the Room, a Sheet opened from Faces |
| The browser needs a tap (sound, autoplay) | One `glass` Button in the middle of the picture: “Tap for sound” | Everything else |
| Something fails | One `body` sentence in `danger` saying what to do (“Can't reach Ada's screen. Is it on the same Wi-Fi?”) and one Button | Error codes, logs |

Rules of thumb: if a control is used less than once per movie, put it in a Disclosure or Panel. If a state isn't something either person can act on, don't show it. Never show the Dock and the PlayerBar together.

## Core flows

1. **Start:** tap the small `accent` + in the Dock → a Sheet grows from it: paste a link (Field), pick a movie (List), share a tab, or go to Netflix & other sites. Playback starts paused on both screens with the Join card shown to the other person.
2. **Join:** the other screen shows one MediaCard (“Arrival — Moses is watching”) with a glass **play** button. One tap and both are watching. No codes, no rooms, no setup screens in the way.
3. **Watch:** full picture. Touch to reveal the PlayerBar; pause/seek on either screen moves both.
4. **Leave and return:** their dot in Faces turns `away` and a Notice appears; when the person comes back it disappears on its own.
5. **The Room:** tap Faces (or the ♥ tile on Home) → a Sheet with who's here (Presence), volume (Slider), subtitles / auto-pause / your name (Disclosures) and **Stop watching**, which asks for a second tap because it stops both screens.

## Content

- Voice: warm, brief, human. Speak about the two people by name, never “users”, “peers” or “clients”: “Ada is watching Arrival”, “Moses stepped away”.
- Sentence case everywhere: “Watch together”, not “Watch Together”. No exclamation marks, no emoji in UI copy.
- Buttons start with a verb and are two or three words: “Join Ada”, “Share a tab”, “Pick a movie”.
- Say what will happen, not how it works: “Pauses when someone leaves the room”, not “Presence detection via camera”.
- Numbers only when someone needs them: “In sync”, not “drift 12 ms” (that detail lives in `detail` for people who open Presence).

## Colour

- Lay every screen on `ground`; float panels on `surface-raised` with `shadow-card` and a `line` hairline; use `surface` for whole sheets.
- Default pills are `fill` with `ink` text; selected rows `fill-soft`; slider fills `fill-strong`.
- Text: `ink` for anything that matters, `ink-muted` for values and second lines, `ink-faint` only for placeholders and disabled labels.
- `accent` (+ `on-accent` text, never white) for the single primary action and the live progress line; `accent-ink` when the accent must be words.
- On imagery: `on-media` / `on-media-muted` text, always over `media-scrim`; controls in `glass` with a 20px backdrop blur. Glass never appears on plain ground.
- Status: `live` (blue) for here / in sync, `away` (orange) for stepped away / waiting, `danger` for errors. Each always comes with a word.
- Two themes: **Daylight** (first, the default for setup and browsing) and **Cinema** (dark, for watching). The player, and any screen shown while something plays, uses Cinema: set `data-theme="dark"` on its root.

## Type

- One family: Geist (falls back to the system sans), loaded from Google Fonts; Geist Mono for timecodes only.
- `display` (56/60, 300) for one word or a title over media, `title` (32/38, 300) once per screen, `headline` (20/26) for large pill labels, `body` (16/24) for sentences, `label` (14/20, 500) for buttons and names, `caption` (13/18) for second lines and panel titles, `micro` (12/16) for slider values, `time` (13/18 mono) for timecodes.
- Large text is always light (300); weight comes from size, not boldness. Never use 600+ in the UI.

## Shape and space

- `radius-pill` for every button, chip and bar; `radius-xl` (36px) for media and the player frame; `radius-lg` for the solid app tile and phone sheets; `radius-md` for panels; `radius-sm` for list rows; `radius-xs` for thumbnails.
- Stack related pills and cards `space-4` apart; separate groups by `space-8`; screen edges `space-6` on phones and `space-12` on larger screens.
- Compose like the references: a few large, rounded blocks with generous air between them. If a screen has more than five blocks, something should be hidden.

## Motion

Motion is how SharedLove feels alive. Nothing is static and nothing is twitchy: every reaction has weight, a little momentum, and then rest. Use the tokens and the engine; never invent a timing.

### The principles, applied

- **Anticipation:** pressing a control squashes it first (pills to 0.95 and a touch wider, icon buttons to 0.88) before anything happens.
- **Follow-through:** on release it springs *past* its resting size (pills peak around 1.065), swings back once, and settles in about half a second.
- **Overlapping action:** the icon inside a button is on a looser spring than the button. It is still squashed when the button has recovered, peaks later, and wiggles a few degrees before resting.
- **Squash & stretch:** pills squash wider as they're pressed and stretch taller for a beat as they release. Volume is preserved, never more than 4%.
- **Slow in, slow out:** springs speed up and settle on their own. Nothing moves linearly except the glow's slow turn.
- **Staging:** one thing moves at a time where it matters. Sheets and Home arrive piece by piece, 45–70 ms apart, never all at once.
- **Appeal:** on hover, controls lean a couple of pixels toward the pointer, and a soft light blooms from where you tap.

### How

- **Controls:** call `SharedLove.enableMotion()` once. Every Button, IconButton, list row, Faces and Disclosure then reacts with real springs (the `hover`, `press`, `release` and `icon` presets in `SharedLove.SPRINGS`). They are simulated, not keyframed, so a motion can be interrupted mid-flight and carries its momentum into the next one. Use `SharedLove.pop(el)` to give anything an "I changed" bounce.
- **Arrivals** (Sheets, screens, cards, the List highlight): `ease-spring-soft` over `duration-5`, a real spring with about 4% overshoot.
- **Small reactions** (a status dot popping in, a chevron turning, a Notice dropping in, the + turning into × while its Sheet is open): `ease-bounce` over `duration-6`, about 23% overshoot then a small counter-swing. Never on large surfaces.
- **Leaving** is always quicker and calmer than arriving: `duration-2` with `ease-in`, no bounce.
- **Grow from the trigger:** a Sheet scales up from the button that opened it and shrinks back into it.
- **Screens** crossfade: the old one fades out (`duration-2`, `ease-in`); the new one rises on `ease-spring-soft` 80 ms behind it. The theme (Daylight ↔ Cinema) shifts over `duration-4`.
- **Ambience:** the PlayerBar fades after 2.5 s of stillness (`duration-4`); an empty Home card floats 4 px up and down over seven seconds.

### Glow

A warm ring of light (`glow-1` orange → `glow-2` gold → `glow-3` rose, turning slowly), with a soft blur around it, on **the one element that matters now**. Add `sl-glow`:
- it lights on hover and focus (the name field, the link field);
- `is-breathing` pulses it gently, as an invitation (the Dock's "Start something" while nothing is on);
- `is-glowing` keeps it lit while something is working ("Connecting…").

Never more than one glowing element per view, never behind text, never blue-violet.

### Reduced motion

With `prefers-reduced-motion`, springs, bounces, glow and float stop, and fades remain. The interface still answers every touch, just without movement.

## Iconography

- A small set of 24-grid line icons, 1.5px stroke, round caps and joins (`assets/Icons`, also built into the `Icon` component): play, pause, plus, search, arrow-up-right, globe, heart, volume, screen, close, chevron-down, person, expand, back, subtitles, film, link.
- Icons inherit `currentColor` inside components; the standalone SVG files are drawn in `ink` (#111113).
- 20px inside `md` controls, 24–28px inside `lg`, 16px inside `sm`. Never mix filled and line styles, never use emoji as icons.
- The app mark is the heart tile (`assets/Logos/sharedlove-icon.png`); in the UI, the heart icon in a `solid` squircle IconButton plays the same role.

## Imagery

- Real posters and video frames always win. When there's no picture, use one of the six ambient images (`assets/Ambient`: Greenwood, Sandstone, Harbor, Heather, Rosewater, Slate): soft, grainy, out-of-focus fields of colour that stand in for a room's mood.
- Media always sits in `radius-xl`. Text on media is centred, light, `on-media`, over `media-scrim`.

## Accessibility

- Every text colour meets 4.5:1 on the surfaces its usage note names, in both themes; status dots and focus meet 3:1.
- Focus: a 2px solid `focus` ring, 2px outside the element, on everything interactive.
- Every IconButton has a `label`; Sliders, the List and the PlayerBar track are keyboard-operable (arrow keys).
- Status is never colour alone: Presence always shows words.
- Touch targets are at least 44px (`sm` icon buttons only inside bars, where the bar is the target).

## Using this system

Load `tokens.css`, then `components/bundle.css`, React 18, and `components/bundle.js`; components are on `window.SharedLove` (`Button`, `IconButton`, `MediaCard`, `Dock`, `Panel`, `List`, `Slider`, `Disclosure`, `Presence`, `PlayerBar`, `Sheet`, `Notice`, `Faces`, `Field`, `Icon`). Without React, the same class names (`sl-sheet`, `sl-notice`, `sl-faces`, `sl-field`…) can be applied to plain elements — the SharedLove app does exactly that. Set `data-theme="light"` or `"dark"` on a root element to choose Daylight or Cinema. Class names are prefixed `sl-`.
