# Logos

- `sharedlove-icon.png` — the app icon (512 × 512): a pale heart on a plum field. Used for the home-screen icon and favicon. There is no wordmark: set “SharedLove” in Geist Light (`title` or `display`) when the name is needed.
