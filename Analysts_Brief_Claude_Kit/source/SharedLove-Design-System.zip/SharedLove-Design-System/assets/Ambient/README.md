# Ambient

Six soft, grainy, out-of-focus colour fields (640×640 JPEG) that stand in when there is no poster or frame: placeholder media, a room's mood, the background of an empty MediaCard. Always shown inside `radius-xl` (or `radius-xs` as a List thumbnail). Never put body text on them without `media-scrim`.

- `greenwood.jpg` — deep green to sand.
- `sandstone.jpg` — warm sand and clay.
- `harbor.jpg` — slate blue to mist.
- `heather.jpg` — dusk violet.
- `rosewater.jpg` — dusty rose.
- `slate.jpg` — graphite greys; the most neutral, good behind light UI.
