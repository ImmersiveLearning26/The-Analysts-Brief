# Icons

24-grid line icons, 1.5px stroke, round caps and joins. Single ink: the files are drawn in `ink` (#111113) because an `<img>` can't inherit colour — in code, use the `Icon` component (or inline the SVG) so they take `currentColor`.

- `play`, `pause` — the PlayerBar and Join actions.
- `plus` — start something (the small accent button in the Dock).
- `search` — find a movie (glass, on media).
- `arrow-up-right` — open / go somewhere else.
- `globe` — watch a website together.
- `heart` — SharedLove home (in the solid app tile).
- `volume` — sound settings.
- `screen` — share a tab or screen.
- `close` — dismiss a panel or sheet.
- `chevron-down` — Disclosure state.
- `person` — who's watching / presence settings.
- `expand` — full screen.
- `back` — go back a step.
- `subtitles` — subtitles on/off.
- `film` — your movies.
- `link` — copy or open a link.
